import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from typer_core.models import (DEFAULT_IGNORE_SPEC, AppState, IgnoreFilter,  # noqa: E402
                               TextStyle, split_lines)
from typer_core.store import StateStore  # noqa: E402

SPEC = "1, 2, 3, 4, 5, 6, 7, 8, 9, 0, *, -, #"


class IgnoreFilterTests(unittest.TestCase):
    def setUp(self):
        self.f = IgnoreFilter(SPEC)

    def test_lines_starting_with_configured_chars_are_ignored(self):
        for line in ("1. Hola", "12 años", "0", "* nota", "- guion", "#Página 3", "  \t- con sangría"):
            self.assertTrue(self.f.is_ignored(line), line)
            self.assertEqual(self.f.clean(line), "", line)

    def test_normal_lines_are_kept_untouched(self):
        self.assertEqual(self.f.clean("Hola mundo"), "Hola mundo")
        self.assertEqual(self.f.clean("  ¿Qué? - dijo  "), "¿Qué? - dijo")   # prefijo solo al inicio
        self.assertEqual(self.f.clean("...Bueno"), "...Bueno")

    def test_blank_lines_are_skipped_but_not_reported_as_ignored(self):
        self.assertEqual(self.f.clean("   "), "")
        self.assertFalse(self.f.is_ignored("   "))

    def test_bom_and_spacing_variants(self):
        self.assertTrue(self.f.is_ignored("\ufeff# Capítulo"))

    def test_separators_commas_and_spaces_and_multichar_tokens(self):
        f = IgnoreFilter("1,2 ,  //,[SFX]")
        self.assertTrue(f.is_ignored("// comentario"))
        self.assertTrue(f.is_ignored("[SFX] BOOM"))
        self.assertTrue(f.is_ignored("2 cosas"))
        self.assertFalse(f.is_ignored("3 cosas"))

    def test_empty_spec_ignores_nothing_except_blanks(self):
        f = IgnoreFilter("")
        self.assertEqual(f.clean("- Hola"), "- Hola")


class AppStateTests(unittest.TestCase):
    def make(self, text, spec=SPEC):
        return AppState(script_text=text, ignore_spec=spec)

    def test_empty_script(self):
        self.assertIsNone(self.make("").current_entry())
        self.assertIsNone(self.make("\n  \n").current_entry())

    def test_walk_skips_ignored_and_blank_lines_automatically(self):
        st = self.make("1. Uno\n\n# nota\nHola\n- otra\nAdiós\n* fin")
        seen = []
        while (e := st.current_entry()) is not None:
            seen.append((e.index, e.text))
            st.advance()
        self.assertEqual(seen, [(3, "Hola"), (5, "Adiós")])
        self.assertFalse(st.advance())

    def test_progress_counts_only_valid_lines(self):
        st = self.make("# t\nA\n1. x\nB\nC")
        self.assertEqual(st.progress(), (0, 3))
        st.advance()
        self.assertEqual(st.progress(), (1, 3))

    def test_ignored_indices(self):
        st = self.make("# t\nA\n\n1. x\nB")
        self.assertEqual(st.ignored_indices(), {0, 3})

    def test_retreat_skips_ignored(self):
        st = self.make("A\n# x\n- y\nB")
        st.select_line(3)
        self.assertTrue(st.retreat())
        self.assertEqual(st.current_entry().text, "A")
        self.assertFalse(st.retreat())

    def test_retreat_from_end(self):
        st = self.make("A\nB")
        st.advance(); st.advance()
        self.assertIsNone(st.current_entry())
        self.assertTrue(st.retreat())
        self.assertEqual(st.current_entry().text, "B")

    def test_select_line_on_ignored_goes_to_next_valid(self):
        st = self.make("A\n# x\nB")
        self.assertEqual(st.select_line(1).text, "B")
        self.assertEqual(st.cursor, 2)

    def test_select_line_after_last_valid_falls_back_to_last_valid(self):
        st = self.make("A\nB\n# fin\n")
        self.assertEqual(st.select_line(2).text, "B")
        self.assertEqual(st.select_line(10 ** 9).text, "B")

    def test_select_line_with_nothing_valid(self):
        self.assertIsNone(self.make("# a\n- b").select_line(0))

    def test_move_does_not_run_past_the_end(self):
        st = self.make("A\n# x\nB")
        self.assertTrue(st.move(+1))
        self.assertEqual(st.current_entry().text, "B")
        self.assertFalse(st.move(+1))
        self.assertEqual(st.current_entry().text, "B")
        self.assertTrue(st.move(-1))
        self.assertEqual(st.current_entry().text, "A")

    def test_line_numbers_match_gtk_buffer_lines(self):
        self.assertEqual(split_lines("a\r\nb\rc\nd"), ["a", "b", "c", "d"])

    def test_rename_style_keeps_order_and_active(self):
        st = AppState()
        names = list(st.styles)
        st.active_style = names[1]
        st.rename_style(names[1], "hola")
        self.assertEqual(list(st.styles)[1], "hola")
        self.assertEqual(st.active_style, "hola")
        self.assertEqual(st.styles["hola"].name, "hola")
        with self.assertRaises(ValueError):
            st.rename_style("hola", names[0])

    def test_style_fallbacks(self):
        st = AppState(active_style="no-existe")
        self.assertIn(st.active_style, st.styles)

    def test_uppercase_transform(self):
        self.assertEqual(TextStyle("x", uppercase=True).transform("hola"), "HOLA")

    def test_legacy_ignore_spec_is_migrated(self):
        st = AppState.from_dict({"ignore_spec": "1, 2, 3... * - _", "script_text": "x"})
        self.assertEqual(st.ignore_spec, DEFAULT_IGNORE_SPEC)
        custom = AppState.from_dict({"ignore_spec": "//, ##"})
        self.assertEqual(custom.ignore_spec, "//, ##")


class StoreTests(unittest.TestCase):
    def test_roundtrip_and_failed_transaction_does_not_persist(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = StateStore(tmp)
            with store.transaction() as st:
                st.script_text = "A\nB"
                st.advance()
                st.styles["Nuevo"] = TextStyle("Nuevo", size=50)
            loaded = store.load()
            self.assertEqual(loaded.cursor, 1)
            self.assertEqual(loaded.styles["Nuevo"].size, 50)
            with self.assertRaises(RuntimeError):
                with store.transaction() as st:
                    st.advance()
                    raise RuntimeError("falló la inserción")
            self.assertEqual(store.load().cursor, 1)

    def test_apply_on_click_defaults_on_and_persists(self):
        self.assertTrue(AppState().apply_on_click)
        with tempfile.TemporaryDirectory() as tmp:
            store = StateStore(tmp)
            self.assertTrue(store.load().apply_on_click)          # archivo inexistente → valor por defecto
            with store.transaction() as st:
                st.apply_on_click = False
            self.assertFalse(store.load().apply_on_click)

    def test_state_file_without_apply_on_click_gets_default(self):
        self.assertTrue(AppState.from_dict({"script_text": "x"}).apply_on_click)

    def test_old_state_file_gets_new_default_filter(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = StateStore(tmp)
            with open(store.path, "w", encoding="utf-8") as fh:
                json.dump({"script_text": "1. x\nHola", "ignore_spec": "1, 2, 3... * - _"}, fh)
            st = store.load()
            self.assertEqual(st.ignore_spec, DEFAULT_IGNORE_SPEC)
            self.assertEqual(st.current_entry().text, "Hola")

    def test_corrupt_file_is_recovered(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = StateStore(tmp)
            with open(store.path, "w") as fh:
                fh.write("{no es json")
            self.assertEqual(store.load().cursor, 0)
            self.assertTrue(os.path.exists(store.path + ".corrupt"))


class IntegrationTests(unittest.TestCase):
    """Detectan desfases entre módulos sin necesitar GIMP ni GTK."""

    CORE = os.path.join(os.path.dirname(__file__), "..", "typer_core")
    MODULES = ("models", "store", "typesetter", "actions", "panel")

    def _tree(self, name):
        import ast
        with open(os.path.join(self.CORE, f"{name}.py"), encoding="utf-8") as fh:
            return ast.parse(fh.read())

    def _top_level_names(self, name):
        import ast
        names = set()
        for node in self._tree(name).body:
            if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                names.add(node.name)
            elif isinstance(node, ast.Assign):
                names.update(t.id for t in node.targets if isinstance(t, ast.Name))
            elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                names.add(node.target.id)
        return names

    def test_all_modules_share_the_package_version(self):
        import re
        import typer_core
        for name in self.MODULES:
            with open(os.path.join(self.CORE, f"{name}.py"), encoding="utf-8") as fh:
                m = re.search(r'^__version__ = "([^"]+)"', fh.read(), re.M)
            self.assertIsNotNone(m, f"{name}.py no declara __version__")
            self.assertEqual(m.group(1), typer_core.__version__, name)

    def test_relative_imports_point_to_existing_names(self):
        import ast
        for name in self.MODULES:
            for node in ast.walk(self._tree(name)):
                if isinstance(node, ast.ImportFrom) and node.level == 1 and node.module:
                    defined = self._top_level_names(node.module)
                    for alias in node.names:
                        self.assertIn(alias.name, defined,
                                      f"{name}.py importa {alias.name} de {node.module}.py y no existe")

    def test_no_text_layer_selected_is_a_typeset_error_and_exported(self):
        import ast
        classes = {n.name: n for n in self._tree("typesetter").body if isinstance(n, ast.ClassDef)}
        self.assertIn("NoTextLayerSelected", classes)
        bases = [b.id for b in classes["NoTextLayerSelected"].bases if isinstance(b, ast.Name)]
        self.assertEqual(bases, ["TypesetError"])

    def test_selection_bounds_unpacks_five_values(self):
        with open(os.path.join(self.CORE, "typesetter.py"), encoding="utf-8") as fh:
            self.assertIn("non_empty, x1, y1, x2, y2 = Gimp.Selection.bounds(image)[-5:]", fh.read())

    def test_verify_install_ok_and_detects_mismatch(self):
        import typer_core
        typer_core.verify_install(("models", "store"))                # sin gi: debe pasar
        original = typer_core.__version__
        typer_core.__version__ = "0.0.0-otra"
        try:
            with self.assertRaises(RuntimeError) as ctx:
                typer_core.verify_install(("models",))
            self.assertIn("desincronizado", str(ctx.exception))
        finally:
            typer_core.__version__ = original


if __name__ == "__main__":
    unittest.main()
